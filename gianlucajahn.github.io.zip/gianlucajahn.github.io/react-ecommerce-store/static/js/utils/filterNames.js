const filterNames = [
    "Wishlist",
    "Ratings",
    "Reviews",
    "Action",
    "Strategy",
    "RPG",
    "Shooter",
    "Adventure",
    "Puzzle",
    "Racing",
    "Sports"
];

export default filterNames;